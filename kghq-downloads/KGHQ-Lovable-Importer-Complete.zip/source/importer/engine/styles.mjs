import postcss from "postcss";
import selectorParser from "postcss-selector-parser";
export async function scopeCSS(css, scope) {
  css = css.replace(/--[A-Za-z_][\w-]*/g, (name) => "--" + scope + "-" + name.slice(2));
  const root = postcss.parse(css);
  const families = new Map();
  root.walkAtRules("font-face", (rule) =>
    rule.walkDecls("font-family", (decl) => {
      const family = decl.value.replace(/^['"]|['"]$/g, "");
      families.set(family, scope + "-" + family);
    }),
  );
  root.walkDecls((decl) => {
    if (
      decl.prop === "font-family" ||
      (decl.prop.startsWith("--") && /font|family|typeface|typography/.test(decl.prop))
    )
      decl.value = decl.value
        .split(",")
        .map((part) => {
          const family = part.trim().replace(/^['"]|['"]$/g, "");
          return families.has(family) ? '"' + families.get(family) + '"' : part;
        })
        .join(",");
  });
  // Theme CSS is usually unlayered; export Tailwind layers in source order at the same cascade level.
  root.walkAtRules("layer", (rule) => {
    if (rule.nodes) rule.replaceWith(...rule.nodes);
    else rule.remove();
  });
  const keyframes = new Map();
  root.walkAtRules((rule) => {
    if (/keyframes$/.test(rule.name)) {
      const name = rule.params;
      keyframes.set(name, scope + "-" + name);
      rule.params = scope + "-" + name;
    }
  });
  root.walkDecls((decl) => {
    if (/^animation(?:-name)?$/.test(decl.prop))
      for (const [name, scoped] of keyframes)
        decl.value = decl.value.replace(
          new RegExp("(?<![\\w-])" + name + "(?![\\w-])", "g"),
          scoped,
        );
  });
  root.walkAtRules((rule) => {
    if (["import", "charset"].includes(rule.name)) rule.remove();
  });
  root.walkRules((rule) => {
    if (rule.parent.type === "atrule" && /keyframes$/.test(rule.parent.name)) return;
    let nested = false;
    selectorParser((selectors) =>
      selectors.walkNesting(() => {
        nested = true;
      }),
    ).processSync(rule.selector);
    if (nested) return;
    rule.selector = selectorParser((selectors) =>
      selectors.each((selector) => {
        let foundRoot = false;
        selector.walk((node) => {
          if (
            (node.type === "pseudo" && node.value === ":root") ||
            (node.type === "tag" && ["html", "body"].includes(node.value))
          ) {
            node.replaceWith(selectorParser.className({ value: scope }));
            foundRoot = true;
          }
        });
        if (!foundRoot) {
          selector.prepend(selectorParser.combinator({ value: " " }));
          selector.prepend(selectorParser.className({ value: scope }));
        }
      }),
    ).processSync(rule.selector);
  });
  return root.toString();
}
export async function leafCSS(css, scope, leaves) {
  const root = postcss.parse(css);
  const classes = new Map();
  for (const leaf of leaves)
    for (const name of leaf.className.split(/\s+/).filter(Boolean)) {
      if (!classes.has(name)) classes.set(name, new Set());
      classes.get(name).add(leaf.tag);
    }
  root.walkRules((rule) => {
    if (rule.parent.type === "atrule" && /keyframes$/.test(rule.parent.name)) return;
    if (rule.selector.includes("wp-block-")) return;
    let nested = false;
    selectorParser((selectors) =>
      selectors.walkNesting(() => {
        nested = true;
      }),
    ).processSync(rule.selector);
    if (nested) return;
    const additions = [];
    selectorParser((selectors) =>
      selectors.each((sel) => {
        const tail = [];
        for (let i = sel.nodes.length - 1; i >= 0 && sel.nodes[i].type !== "combinator"; i--)
          tail.push(sel.nodes[i]);
        const targets = new Set();
        for (const n of tail)
          if (n.type === "class" && classes.has(n.value))
            for (const tag of classes.get(n.value)) targets.add(tag);
        for (const tag of targets) {
          const s = sel.clone();
          const pseudos = [];
          while (s.last?.type === "pseudo") pseudos.unshift(s.last.remove());
          s.append(selectorParser.combinator({ value: " > " }));
          s.append(
            tag === "img"
              ? selectorParser.tag({ value: "img" })
              : selectorParser.className({ value: "wp-block-button__link" }),
          );
          for (const p of pseudos) s.append(p);
          additions.push(s.toString());
        }
      }),
    ).processSync(rule.selector);
    if (additions.length) rule.selector += "," + additions.join(",");
  });
  return root.toString();
}
