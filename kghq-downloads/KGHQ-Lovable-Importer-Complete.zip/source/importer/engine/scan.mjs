import fs from "node:fs/promises";
import path from "node:path";
import ts from "typescript";
export async function scan(repo) {
  const root = path.resolve(repo);
  const routes = [];
  const warnings = [];
  async function walk(dir) {
    for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
      if (
        ["node_modules", ".git", ".output", "dist", "importer"].includes(entry.name) ||
        entry.isSymbolicLink()
      )
        continue;
      const file = path.join(dir, entry.name);
      if (entry.isDirectory()) await walk(file);
      else if (/\.[jt]sx?$/.test(file)) {
        const text = await fs.readFile(file, "utf8");
        const ast = ts.createSourceFile(
          file,
          text,
          ts.ScriptTarget.Latest,
          true,
          ts.ScriptKind.TSX,
        );
        function visit(node) {
          if (
            ts.isCallExpression(node) &&
            ts.isIdentifier(node.expression) &&
            node.expression.text === "createFileRoute" &&
            ts.isStringLiteral(node.arguments[0])
          ) {
            const route = node.arguments[0].text.replace(/_(?=\/|$)/g, "");
            if (route.includes("$"))
              warnings.push({
                route,
                file: path.relative(root, file),
                reason: "Dynamic route requires explicit concrete URLs via --routes.",
              });
            else
              routes.push({
                path: route,
                title: route === "/" ? "Home" : route.slice(1).replaceAll("-", " "),
                file: path.relative(root, file),
              });
          }
          ts.forEachChild(node, visit);
        }
        visit(ast);
        // React Router route declarations are reported rather than executed.
        if (text.includes("<Route ") && !text.includes("createFileRoute"))
          warnings.push({
            file: path.relative(root, file),
            reason:
              "JSX router configuration needs explicit --routes; only TanStack file routes are auto-detected in MVP.",
          });
      }
    }
  }
  await walk(root);
  // Repository adapter: resolve this site's article catalog without evaluating TypeScript.
  const articleRoute = warnings.find((w) => w.route === "/articles/$slug");
  if (articleRoute) {
    try {
      const source = await fs.readFile(path.join(root, "src/lib/articles.ts"), "utf8");
      const ast = ts.createSourceFile("articles.ts", source, ts.ScriptTarget.Latest, true);
      function visit(node) {
        if (
          ts.isPropertyAssignment(node) &&
          node.name.getText(ast) === "slug" &&
          ts.isStringLiteral(node.initializer) &&
          /^[a-z0-9-]+$/.test(node.initializer.text)
        )
          routes.push({
            path: "/articles/" + node.initializer.text,
            title: node.initializer.text.replaceAll("-", " "),
            file: "src/lib/articles.ts",
            adapter: "kghq-articles",
          });
        ts.forEachChild(node, visit);
      }
      visit(ast);
      articleRoute.reason =
        "Concrete article URLs detected using the KGHQ article-catalog adapter. Other runtime parameters still require explicit URLs.";
    } catch {}
  }
  return {
    schemaVersion: 1,
    routes: [...new Map(routes.map((r) => [r.path, r])).values()].sort((a, b) =>
      a.path.localeCompare(b.path),
    ),
    warnings,
  };
}
