import { test } from "node:test";
import assert from "node:assert/strict";
import { scan } from "./scan.mjs";
import { scopeCSS, leafCSS } from "./styles.mjs";
import { checkout } from "./github.mjs";
import { convertTree, serialize, validateContent } from "./blocks.mjs";
test("AST scanner finds static routes and nine catalog articles without executing React", async (t) => {
  const repo = process.env.KGHQ_TEST_REPO || new URL("../../", import.meta.url).pathname;
  const fs = await import("node:fs/promises");
  try {
    await fs.access(repo + "/src/lib/articles.ts");
  } catch {
    t.skip("Set KGHQ_TEST_REPO to this Lovable repository for its catalog fixture.");
    return;
  }
  const result = await scan(repo);
  assert.equal(result.routes.filter((r) => r.adapter === "kghq-articles").length, 9);
  assert.ok(result.routes.some((r) => r.path === "/bizphone"));
  assert.ok(result.routes.some((r) => r.path === "/articles"));
  assert.ok(!result.routes.some((r) => r.path.includes("$")));
});
test("scoping contains reset, root variables, media selectors, hover, layers, and keyframes", async () => {
  const css = await scopeCSS(
    "@layer utilities{.red:hover{color:red}} :root{--color:red} @media(max-width:600px){.a{display:none}} @keyframes spin{to{transform:rotate(1turn)}} .animate{animation:spin 1s}",
    "kghq-page-123456abcdef",
  );
  assert.match(css, /\.kghq-page-123456abcdef \.red:hover/);
  assert.match(css, /\.kghq-page-123456abcdef\{--kghq-page-123456abcdef-color/);
  assert.match(css, /\.kghq-page-123456abcdef \.a/);
  assert.match(css, /@keyframes kghq-page-123456abcdef-spin/);
  assert.doesNotMatch(css, /@layer/);
  assert.doesNotMatch(css, /\.kghq-page-123456abcdef to/);
});
test("native wrappers receive image and button utility styles", async () => {
  const css = await leafCSS(".kghq-page-x .w-full{width:100%}", "kghq-page-x", [
    { className: "w-full", tag: "img" },
  ]);
  assert.match(css, /\.w-full > img/);
});
test("GitHub arguments reject command/options injection before network", async () => {
  await assert.rejects(checkout("foo;bar/repo"));
  await assert.rejects(checkout("foo/bar", "--upload-pack=evil"));
});
test("canonical native blocks survive parse/save without recovery", () => {
  const tree = {
    type: "group",
    classes: "grid md:grid-cols-2",
    children: [
      { type: "heading", classes: "title", level: 2, html: "Editable <strong>heading</strong>" },
      { type: "button", classes: "btn", html: "Read more", href: "/about" },
    ],
  };
  const blocks = convertTree(tree);
  assert.equal(blocks[0].name, "core/columns");
  const content = serialize(blocks);
  assert.deepEqual(validateContent(content), []);
  assert.doesNotMatch(content, /wp:html|iframe|<script/);
});
test("native Details preserves editable summary, inline icons, and child content", () => {
  const blocks = convertTree({
    type: "details",
    classes: "faq",
    open: false,
    summary: 'Question <img class="size-4" src="https://example.com/icon.png" alt="">',
    children: [{ type: "text", html: "Editable answer" }],
  });
  const content = serialize(blocks);
  assert.equal(blocks[0].name, "core/details");
  assert.deepEqual(validateContent(content), []);
  assert.match(content, /<details/);
});
test("escaped ampersands in utility class names do not bypass selector scoping", async () => {
  const css = await scopeCSS(".\\[\\&\\>svg\\]\\:size-4>svg{width:1rem}", "kghq-page-123456abcdef");
  assert.match(css, /^\.kghq-page-123456abcdef /);
});
test("font-face names and font family variables are namespaced together", async () => {
  const css = await scopeCSS(
    '@font-face{font-family:"Manrope";src:url(font.woff2)}:root{--font-body:Manrope,sans-serif}.body{font-family:var(--font-body)}',
    "kghq-page-123456abcdef",
  );
  assert.match(css, /font-family:"kghq-page-123456abcdef-Manrope"/);
  assert.match(
    css,
    /--kghq-page-123456abcdef-font-body:"kghq-page-123456abcdef-Manrope",sans-serif/,
  );
});
test("zero-width content preserves decorative inline spans without block recovery", () => {
  const content = serialize([
    convertTree({ type: "text", html: '<span class="h-px w-8">&#8203;</span>Label' })[0],
  ]);
  assert.deepEqual(validateContent(content), []);
  assert.match(content, /h-px w-8/);
});
