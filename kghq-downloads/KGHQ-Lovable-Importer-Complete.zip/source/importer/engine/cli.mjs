#!/usr/bin/env node
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { parseArgs } from "node:util";
import { scan } from "./scan.mjs";
const { values: args } = parseArgs({
  options: {
    repo: { type: "string" },
    github: { type: "string" },
    ref: { type: "string" },
    repository: { type: "string" },
    url: { type: "string" },
    routes: { type: "string" },
    out: { type: "string" },
    chromium: { type: "string" },
  },
});
let checkout;
if (args.github) {
  if (args.repo) throw Error("Choose --repo or --github");
  const { checkout: clone } = await import("./github.mjs");
  checkout = await clone(args.github, args.ref || "main");
  args.repo = checkout.repo;
  args.repository = args.github;
}
if (!args.repo) throw Error("Use --repo PATH or --github owner/repository");
const { execFile } = await import("node:child_process");
const { promisify } = await import("node:util");
let sourceCommit = checkout?.commit || null;
if (!sourceCommit)
  try {
    const { stdout } = await promisify(execFile)("git", ["-C", args.repo, "rev-parse", "HEAD"]);
    if (/^[a-f0-9]{40}$/.test(stdout.trim())) sourceCommit = stdout.trim();
  } catch {}
const detected = await scan(args.repo);
if (!args.url) {
  console.log(JSON.stringify(detected, null, 2));
  await checkout?.cleanup();
  process.exit(0);
}
if (!/^[\w.-]+\/[\w.-]+$/.test(args.repository || ""))
  throw Error("--repository owner/name is required");
const base = new URL(args.url);
if (!["http:", "https:"].includes(base.protocol)) throw Error("Invalid source URL");
const routes = args.routes ? args.routes.split(",") : detected.routes.map((r) => r.path);
for (const route of routes)
  if (
    !route.startsWith("/") ||
    route.startsWith("//") ||
    route.includes("..") ||
    route.includes("#") ||
    route.includes("?")
  )
    throw Error("Routes must be local absolute paths without query/fragment");
const { chromium } = await import("playwright");
const { createBlock, serialize, convertTree, validateContent } = await import("./blocks.mjs");
const { scopeCSS } = await import("./styles.mjs");
const browser = await chromium.launch({
  headless: true,
  executablePath: args.chromium || process.env.KGHQ_CHROMIUM || undefined,
  args: ["--no-sandbox"],
});
const assets = [];
const assetIndex = new Map();
const pages = [];
async function asset(buffer, mime, filename) {
  const id = crypto.createHash("sha256").update(buffer).digest("hex");
  if (!assetIndex.has(id)) {
    assets.push({
      id,
      mime,
      filename: `${id.slice(0, 16)}-${filename.replace(/[^\w.-]/g, "_")}`,
      data: buffer.toString("base64"),
    });
    assetIndex.set(id, true);
  }
  return `https://kghq.invalid/asset/${id}`;
}
try {
  for (const route of routes) {
    console.error(`Converting ${route}`);
    const page = await browser.newPage({
      viewport: { width: 1440, height: 1000 },
      deviceScaleFactor: 1,
    });
    const warnings = [
      "React event-driven behavior is not imported; native Details toggles are preserved. SVG icons are rasterized to transparent PNG media. Internal source links retain original paths; review destination slugs before publishing.",
    ];
    const response = await page.goto(new URL(route, base).href, { waitUntil: "networkidle" });
    if (!response?.ok()) throw Error(`Route ${route}: HTTP ${response?.status()}`);
    await page.evaluate(() => document.fonts.ready);
    await page.emulateMedia({ reducedMotion: "reduce" });
    const scope =
      "kghq-page-" +
      crypto
        .createHash("sha256")
        .update(args.repository + route)
        .digest("hex")
        .slice(0, 12);
    // Preserve static content; do not execute React or serialize event handlers inside WordPress.
    const inaccessible = await page.evaluate(
      () =>
        [...document.styleSheets].filter((sheet) => {
          try {
            void sheet.cssRules;
            return false;
          } catch {
            return true;
          }
        }).length,
    );
    if (inaccessible)
      warnings.push(
        inaccessible +
          " cross-origin stylesheets could not be read; export them as same-origin CSS before relying on font/style fidelity.",
      );
    if (await page.locator("picture,img[srcset]").count())
      warnings.push(
        "Responsive image sources use the desktop currentSrc in this MVP; inspect mobile art direction.",
      );
    const tree = await page.evaluate(() => {
      const skip = new Set(["SCRIPT", "STYLE", "LINK", "META", "NOSCRIPT", "TEMPLATE"]);
      let counter = 0;
      const escape = (s) =>
        s.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
      function inline(el) {
        return [...el.childNodes]
          .map((n) => {
            if (n.nodeType === 3) return escape(n.textContent);
            if (n.nodeType !== 1 || skip.has(n.tagName)) return "";
            if (n.tagName === "BR") return "<br>";
            if (["SVG", "IMG"].includes(n.tagName.toUpperCase())) {
              n.dataset.kghqNode = "n" + counter++;
              return (
                '<img class="' +
                (n.getAttribute("class") || "").replaceAll('"', "&quot;") +
                '" src="https://kghq.invalid/icon/' +
                n.dataset.kghqNode +
                '" alt="">'
              );
            }
            if (["PATH", "CIRCLE"].includes(n.tagName.toUpperCase())) return "";
            const tag = ["STRONG", "EM", "B", "I", "S", "CODE", "SPAN", "A", "SUP", "SUB"].includes(
              n.tagName,
            )
              ? n.tagName.toLowerCase()
              : "span";
            const href =
              tag === "a" && /^(https?:|mailto:|tel:|\/|#)/i.test(n.getAttribute("href") || "")
                ? ' href="' +
                  n.getAttribute("href").replaceAll("&", "&amp;").replaceAll('"', "&quot;") +
                  '"'
                : "";
            const inside =
              inline(n) || (tag === "span" && n.getAttribute("class") ? "&#8203;" : "");
            if (!inside) return "";
            return (
              "<" +
              tag +
              href +
              ' class="' +
              (n.getAttribute("class") || "").replaceAll('"', "&quot;") +
              '">' +
              inside +
              "</" +
              tag +
              ">"
            );
          })
          .join("");
      }
      function visit(el) {
        if (el.nodeType === 3) {
          const s = el.textContent.trim();
          return s ? { type: "text", html: escape(s), classes: "kghq-inline-text" } : null;
        }
        if (el.nodeType !== 1 || skip.has(el.tagName)) return null;
        // Hidden responsive elements are retained, unlike display-only screenshot conversion.
        if (el.matches("[data-radix-popper-content-wrapper],#tanstack-devtools")) return null;
        el.dataset.kghqNode = "n" + counter++;
        const attrs = {
          tag: el.tagName.toLowerCase(),
          classes: (el.getAttribute("class") || "") + " kghq-" + el.dataset.kghqNode,
          id: el.id,
        };
        const children = () => [...el.childNodes].map(visit).filter(Boolean);
        if (/^H[1-6]$/.test(el.tagName))
          return { ...attrs, type: "heading", level: Number(el.tagName[1]), html: inline(el) };
        if (el.tagName === "IMG")
          return { ...attrs, type: "image", src: el.currentSrc || el.src, alt: el.alt };
        if (el.tagName.toUpperCase() === "SVG")
          return {
            ...attrs,
            type: "image",
            icon: el.dataset.kghqNode,
            alt: el.getAttribute("aria-label") || "Decorative icon",
          };
        if (
          el.tagName === "P" ||
          (["SPAN", "SMALL", "LABEL"].includes(el.tagName) && !el.querySelector("div,p,img,svg"))
        )
          return { ...attrs, type: "text", html: inline(el) };
        if (el.tagName === "A" && !el.querySelector("div,img"))
          return {
            ...attrs,
            type: "button",
            href: el.getAttribute("href") || "#",
            target: el.target,
            html: inline(el),
          };
        if (["UL", "OL"].includes(el.tagName) && !el.querySelector("li div,li p,li svg"))
          return {
            ...attrs,
            type: "list",
            ordered: el.tagName === "OL",
            items: [...el.children].map(inline),
          };
        if (el.tagName === "DETAILS") {
          const summary = el.querySelector(":scope > summary");
          return {
            ...attrs,
            type: "details",
            open: el.open,
            summary: summary
              ? '<span class="' +
                (summary.getAttribute("class") || "").replaceAll('"', "&quot;") +
                '">' +
                inline(summary) +
                "</span>"
              : "Details",
            children: [...el.childNodes]
              .filter((n) => n !== summary)
              .map(visit)
              .filter(Boolean),
          };
        }
        if (el.tagName === "HR") return { ...attrs, type: "separator" };
        if (
          ["BUTTON", "INPUT", "SELECT", "TEXTAREA", "FORM", "IFRAME", "VIDEO", "CANVAS"].includes(
            el.tagName,
          )
        )
          return {
            ...attrs,
            type: "unsupported",
            reason:
              el.tagName +
              " requires an accessible custom block or WordPress form integration; static content only.",
            children: el.tagName === "BUTTON" ? [{ type: "text", html: inline(el) }] : children(),
          };
        return { ...attrs, type: "group", children: children() };
      }
      return visit(document.body);
    });
    let css = await page.evaluate(() =>
      [...document.styleSheets]
        .map((sheet) => {
          try {
            return [...sheet.cssRules].map((r) => r.cssText).join("\n");
          } catch {
            return "";
          }
        })
        .join("\n"),
    );
    css += await page.evaluate(() =>
      [...document.querySelectorAll("[data-kghq-node][style]")]
        .map((el) => ".kghq-" + el.dataset.kghqNode + "{" + el.getAttribute("style") + "}")
        .join("\n"),
    );
    if (!css.trim())
      throw Error("No readable compiled CSS; serve same-origin styles or provide CORS access.");
    // Fetch assets with browser request context; credentials never enter the bundle.
    async function fetchAsset(url) {
      const u = new URL(url, base);
      if (!["http:", "https:", "data:"].includes(u.protocol))
        throw Error("Unsupported asset protocol");
      const res = await page.request.get(u.href);
      if (!res.ok()) throw Error(`Asset HTTP ${res.status()}: ${u.pathname}`);
      const mime = (res.headers()["content-type"] || "").split(";")[0];
      return asset(await res.body(), mime, path.basename(u.pathname) || "asset");
    }
    async function captureIcon(key) {
      const el = page.locator(`[data-kghq-node="${key}"]`);
      const box = await el.boundingBox();
      if (!box || !box.width || !box.height) {
        warnings.push("Hidden SVG icon omitted: " + key);
        return null;
      }
      if (await el.evaluate((e) => e.tagName.toUpperCase() === "IMG"))
        return fetchAsset(await el.evaluate((e) => e.currentSrc || e.src));
      const png = await el.evaluate(async (svg) => {
        const clone = svg.cloneNode(true);
        const originals = [svg, ...svg.querySelectorAll("*")];
        const copies = [clone, ...clone.querySelectorAll("*")];
        originals.forEach((node, i) => {
          const style = getComputedStyle(node);
          for (const property of [
            "fill",
            "stroke",
            "stroke-width",
            "stroke-linecap",
            "stroke-linejoin",
            "opacity",
            "fill-rule",
            "clip-rule",
            "color",
          ])
            copies[i].style.setProperty(property, style.getPropertyValue(property));
        });
        const box = svg.getBoundingClientRect();
        clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
        clone.setAttribute("width", box.width);
        clone.setAttribute("height", box.height);
        clone.style.width = box.width + "px";
        clone.style.height = box.height + "px";
        const xml = new XMLSerializer().serializeToString(clone);
        const image = new Image();
        image.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(xml);
        await image.decode();
        const canvas = document.createElement("canvas");
        canvas.width = Math.ceil(box.width * 2);
        canvas.height = Math.ceil(box.height * 2);
        canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
        return canvas.toDataURL("image/png").split(",")[1];
      });
      return asset(Buffer.from(png, "base64"), "image/png", "icon.png");
    }
    async function replaceInline(html) {
      for (const key of [
        ...new Set(
          [...html.matchAll(/https:\/\/kghq\.invalid\/icon\/(n[0-9]+)/g)].map((m) => m[1]),
        ),
      ]) {
        const url = await captureIcon(key);
        html = html.split("https://kghq.invalid/icon/" + key).join(url || "");
      }
      return html;
    }
    async function walk(n) {
      if (n.type === "image") {
        if (n.icon) {
          n.src = await captureIcon(n.icon);
          if (!n.src) {
            n.type = "group";
            n.children = [];
          }
          delete n.icon;
        } else n.src = await fetchAsset(n.src);
      }
      if (n.summary) n.summary = await replaceInline(n.summary);
      if (n.html) n.html = await replaceInline(n.html);
      if (n.items) n.items = await Promise.all(n.items.map(replaceInline));
      for (const c of n.children || []) await walk(c);
    }
    await walk(tree);
    // Resolve original background images and fonts; remote CSS imports are explicitly not silently accepted.
    if (/@import\b/.test(css))
      warnings.push("External CSS @import requires manual font/style review; imports are removed.");
    css = css.replace(/@import[^;]+;/g, "");
    const urls = [
      ...new Set([...css.matchAll(/url\(\s*["']?([^\s"')]+)["']?\s*\)/g)].map((m) => m[1])),
    ];
    for (const url of urls) {
      try {
        const target = await fetchAsset(url);
        css = css.split(url).join(target);
      } catch (error) {
        warnings.push(
          "A CSS background/font asset could not be preserved; its URL was removed. Check source asset availability.",
        );
        css = css.split(url).join("data:,");
      }
    }
    css = await scopeCSS(css, scope);
    const typography = await page.evaluate(() => {
      const s = getComputedStyle(document.body);
      return {
        fontFamily: s.fontFamily,
        fontSize: s.fontSize,
        lineHeight: s.lineHeight,
        color: s.color,
        loadedFaces: [...document.fonts].map((f) => ({ family: f.family, status: f.status })),
      };
    });
    let bodyFont = typography.fontFamily;
    for (const face of typography.loadedFaces) {
      const family = face.family.replace(/^['"]|['"]$/g, "");
      if (css.includes(scope + "-" + family))
        bodyFont = bodyFont
          .split(",")
          .map((part) =>
            part.trim().replace(/^['"]|['"]$/g, "") === family
              ? '"' + scope + "-" + family + '"'
              : part,
          )
          .join(",");
    }
    css += `\n.${scope}{font-family:${bodyFont};font-size:${typography.fontSize};line-height:${typography.lineHeight};color:${typography.color}}\n`;
    css += `.${scope} .wp-block-button__link{width:auto;height:auto;text-align:inherit;word-break:normal}.${scope} .wp-block-details>summary{list-style:none}\n`;

    css += `\n.${scope} :where(.wp-block-button__link){background:transparent;border:0;border-radius:0;color:inherit;padding:0;font-size:inherit;line-height:inherit;text-decoration:none;box-shadow:none;width:auto}.${scope} .kghq-button-host{display:contents}.${scope} .wp-block-button{display:contents}.${scope} figure.wp-block-image{display:contents}.${scope} .wp-block-image img{display:revert;max-width:100%}.${scope} :where(.wp-block-group){margin-block:0}.${scope} .kghq-inline-text{display:contents}\n`;
    // Move original utility classes from native image/button wrappers to their semantic leaf elements via scoped selectors.
    const extra = [];
    function leaf(n) {
      if (n.type === "image" || n.type === "button")
        extra.push({
          className: n.classes,
          tag: n.type === "image" ? "img" : ".wp-block-button__link",
        });
      for (const c of n.children || []) leaf(c);
    }
    leaf(tree);
    // Rebuild selectors so utility styles reach native image and button leaf nodes.
    const { leafCSS } = await import("./styles.mjs");
    css = await leafCSS(css, scope, extra);
    const blocks = convertTree(tree, warnings);
    const content = serialize([
      createBlock(
        "core/group",
        { className: scope + " kghq-import-root", layout: { type: "default" } },
        blocks,
      ),
    ]);
    const invalid = validateContent(content);
    if (invalid.length) throw Error("Invalid saved blocks: " + invalid.join(","));
    const title = await page.title();
    const outDir = path.resolve(args.out || "./kghq-export");
    await fs.mkdir(outDir, { recursive: true });
    for (const width of [1440, 768, 390]) {
      await page.setViewportSize({ width, height: 1000 });
      await page.screenshot({
        path: path.join(outDir, `${scope}-${width}-source.png`),
        fullPage: true,
      });
    }
    pages.push({
      route,
      title,
      scope,
      content,
      css,
      typography,
      warnings: [...new Set(warnings)],
      sourceHash: crypto
        .createHash("sha256")
        .update(content + css)
        .digest("hex"),
    });
    await page.close();
  }
  const out = path.resolve(args.out || "./kghq-export");
  await fs.mkdir(out, { recursive: true });
  await fs.writeFile(
    path.join(out, "bundle.json"),
    JSON.stringify(
      {
        schemaVersion: 1,
        repository: args.repository,
        sourceCommit,
        createdAt: new Date().toISOString(),
        pages,
        assets,
        scan: detected,
      },
      null,
      2,
    ),
  );
  console.error(`Exported ${pages.length} pages, ${assets.length} assets to ${out}`);
} finally {
  await browser.close();
  await checkout?.cleanup();
}
