<?php
/**
 * Plugin Name: KGHQ Import Styles
 * Description: Independent persistent styling and optional canvas template for KGHQ native-block imports. Keep active after deleting the importer.
 * Version: 0.1.0
 * Requires at least: 6.6
 * Requires PHP: 8.1
 * Author: KGHQ
 * License: GPL-2.0-or-later
 */
if(!defined('ABSPATH'))exit;
function kghq_import_styles_version(){return '0.1.0';}
function kghq_import_styles_css($id){$css=get_post_meta($id,'_kghq_css',true);return is_string($css)&&!preg_match('~</?style~i',$css)?$css:'';}
add_action('wp_enqueue_scripts',function(){if(!is_singular('page'))return;$id=get_queried_object_id();$css=kghq_import_styles_css($id);if(!$css)return;wp_enqueue_style('wp-block-library');wp_register_style('kghq-durable-styles',false,[],'0.1.0');wp_enqueue_style('kghq-durable-styles');wp_add_inline_style('kghq-durable-styles',$css);},100);
// Block editor iframe receives the same scoped CSS; native block controls remain available.
add_action('enqueue_block_assets',function(){if(!is_admin())return;$id=isset($_GET['post'])?absint($_GET['post']):0;if(!$id||!current_user_can('edit_post',$id))return;$css=kghq_import_styles_css($id);if(!$css)return;wp_register_style('kghq-editor-styles',false,[],'0.1.0');wp_enqueue_style('kghq-editor-styles');wp_add_inline_style('kghq-editor-styles',$css);});
add_filter('theme_page_templates',function($templates){$templates['kghq-canvas.php']='KGHQ imported canvas (companion)';return $templates;});
add_filter('template_include',function($template){if(is_singular('page')&&get_page_template_slug()==='kghq-canvas.php'&&get_post_meta(get_queried_object_id(),'_kghq_source_key',true))return __DIR__.'/canvas.php';return $template;},99);
// Classic themes without theme.json receive an extra core Group inner wrapper.
// Unwrap only converter-marked Groups after core's compatibility filter. Saved blocks remain canonical.
add_filter('render_block_core/group',function($html,$block){
 $classes=$block['attrs']['className']??'';
 if(!preg_match('/(?:^|\s)kghq-(?:n[0-9]+|import-root)(?:\s|$)/',$classes))return $html;
 return preg_replace_callback('~^(\s*<(div|section|main|header|footer|article|aside|nav)\b[^>]*>)\s*(<div\b[^>]*class="[^"]*\bwp-block-group__inner-container\b[^"]*"[^>]*>)([\s\S]*)</div>(\s*</\2>\s*)$~',function($m){
  $inner=new WP_HTML_Tag_Processor($m[3]);$outer=new WP_HTML_Tag_Processor($m[1]);
  if($inner->next_tag()&&$outer->next_tag())foreach($inner->class_list() as $class)if($class!=='wp-block-group__inner-container')$outer->add_class($class);
  return $outer->get_updated_html().$m[4].$m[5];
 },$html)??$html;
},11,2);
