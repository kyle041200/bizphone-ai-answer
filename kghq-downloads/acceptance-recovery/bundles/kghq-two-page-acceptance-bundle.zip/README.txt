Developer/staging backup of actual automatic worker output. Normal users do not upload this file.
Repository: kyle041200/bizphone-ai-answer
Routes: /business-support, /marketing
Assets are embedded as integrity-checked base64, not separate uploads. Original remote fonts and the KGHQ light logo are unavailable; review warnings. Source interactions are not migrated. Keep the independent styling companion active.
